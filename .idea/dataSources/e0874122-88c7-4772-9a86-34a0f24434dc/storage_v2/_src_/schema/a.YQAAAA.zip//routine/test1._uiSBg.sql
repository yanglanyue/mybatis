create
  definer = root@localhost procedure test1()
begin
insert into pro_test values(0,'iphone11',8888,'苹果公司','2019-10-08' , 165);
insert into pro_test values(0,'AirPods',1099,'苹果公司','2018-03-15' , 88);
insert into pro_test values(0,'AirPods pro',1999,'苹果公司','2019-11-08' , 5);
insert into pro_test values(0,'MacBook',8999,'苹果公司','2018-05-20' , 12);
insert into pro_test values(0,'MacBook Pro',12998,'苹果公司','2018-09-12' , 8);
insert into pro_test values(0,'beoplay E8',1299,'B&O','2018-02-20' , 15);
insert into pro_test values(0,'beoplay H8',1099,'B&O','2018-05-01' , 12);
insert into pro_test values(0,'PS4',1999,'SONY','2017-12-07' , 45);
insert into pro_test values(0,'PS4 Pro',2499,'SONY','2019-01-01' , 12);
insert into pro_test values(0,'apple watch4',3499,'苹果公司','2018-03-22' , 15);
insert into pro_test values(0,'mate20',3199,'华为','2018-02-04' , 22);
insert into pro_test values(0,'mate30',5299,'华为','2019-08-27' , 50);
insert into pro_test values(0,'P30',3899,'华为','2019-06-29' , 68);
insert into pro_test values(0,'P20',2699,'华为','2018-04-01' , 27);
insert into pro_test values(0,'MateBook',6499,'华为','2018-02-21' , 10);
insert into pro_test values(0,'MateBook Pro',8899,'华为','2019-01-17' , 12);
insert into pro_test values(0,'S9',4899,'三星','2018-02-22' , 12);
insert into pro_test values(0,'S10',6499,'三星','2019-02-16' , 29);
insert into pro_test values(0,'note10',6988,'三星','2019-06-01' , 8);
insert into pro_test values(0,'Xperia 1',6249,'SONY','2019-05-20' , 10);
insert into pro_test values(0,'iMac',14099,'苹果公司','2018-11-28' , 21);
insert into pro_test values(0,'apple watch5',3498,'苹果公司','2019-09-02' , 15);
end;

